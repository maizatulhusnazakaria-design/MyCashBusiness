package com.mycash.business

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.Context
import java.io.File
import java.io.FileOutputStream
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Calendar

private val Green = Color(0xFF16845B)
private val Red = Color(0xFFC44747)
private val Ink = Color(0xFF172B3A)

data class Entry(
    val id: Long, val kind: String, val amount: Double,
    val category: String, val note: String, val date: String, val receiptPath: String = ""
)
data class Debt(
    val id: Long, val kind: String, val person: String,
    val amount: Double, val note: String, val settled: Boolean
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("mycash_local", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Ink)) {
                MyCashApp(
                    loadEntries = {
                        val arr = JSONArray(prefs.getString("entries", "[]"))
                        List(arr.length()) { i ->
                            val o = arr.getJSONObject(i)
                            Entry(o.getLong("id"), o.getString("kind"), o.getDouble("amount"),
                                o.getString("category"), o.getString("note"), o.getString("date"), o.optString("receiptPath", ""))
                        }
                    },
                    saveEntries = { list ->
                        val arr = JSONArray()
                        list.forEach { e -> arr.put(JSONObject().apply {
                            put("id", e.id); put("kind", e.kind); put("amount", e.amount)
                            put("category", e.category); put("note", e.note); put("date", e.date); put("receiptPath", e.receiptPath)
                        }) }
                        prefs.edit().putString("entries", arr.toString()).apply()
                    },
                    loadDebts = {
                        val arr = JSONArray(prefs.getString("debts", "[]"))
                        List(arr.length()) { i ->
                            val o = arr.getJSONObject(i)
                            Debt(o.getLong("id"), o.getString("kind"), o.getString("person"),
                                o.getDouble("amount"), o.getString("note"), o.getBoolean("settled"))
                        }
                    },
                    saveDebts = { list ->
                        val arr = JSONArray()
                        list.forEach { d -> arr.put(JSONObject().apply {
                            put("id", d.id); put("kind", d.kind); put("person", d.person)
                            put("amount", d.amount); put("note", d.note); put("settled", d.settled)
                        }) }
                        prefs.edit().putString("debts", arr.toString()).apply()
                    }
                )
            }
        }
    }
}

@Composable
fun MyCashApp(
    loadEntries: () -> List<Entry>, saveEntries: (List<Entry>) -> Unit,
    loadDebts: () -> List<Debt>, saveDebts: (List<Debt>) -> Unit
) {
    var entries by remember { mutableStateOf(loadEntries().reversed()) }
    var debts by remember { mutableStateOf(loadDebts().reversed()) }
    var tab by remember { mutableStateOf(0) }
    var showEntry by remember { mutableStateOf(false) }
    var showDebt by remember { mutableStateOf(false) }
    var receiptTotal by remember { mutableStateOf("") }
    var receiptText by remember { mutableStateOf("") }
    var showReceiptReview by remember { mutableStateOf(false) }
    var receiptError by remember { mutableStateOf("") }
    var receiptPath by remember { mutableStateOf("") }
    var selectedReceipt by remember { mutableStateOf("") }
    val context = LocalContext.current

    val receiptLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            val receiptFile = File(context.filesDir, "receipt_${System.currentTimeMillis()}.jpg")
            try { FileOutputStream(receiptFile).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }; receiptPath = receiptFile.absolutePath } catch (_: Exception) { receiptPath = "" }
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { result ->
                    receiptText = result.text
                    receiptTotal = detectReceiptTotal(result.text)
                    receiptError = if (receiptTotal.isBlank()) "Jumlah tidak dapat dikenal pasti. Masukkan jumlah secara manual." else ""
                    showReceiptReview = true
                    recognizer.close()
                }
                .addOnFailureListener {
                    receiptError = "Resit tidak dapat dibaca. Cuba ambil gambar yang lebih jelas."
                    receiptTotal = ""
                    showReceiptReview = true
                    recognizer.close()
                }
        }
    }

    val income = entries.filter { it.kind == "Masuk" }.sumOf { it.amount }
    val expense = entries.filter { it.kind == "Keluar" }.sumOf { it.amount }
    val balance = income - expense
    val receivable = debts.filter { it.kind == "Pelanggan berhutang" && !it.settled }.sumOf { it.amount }
    val payable = debts.filter { it.kind == "Hutang pembekal" && !it.settled }.sumOf { it.amount }

    Scaffold(
        topBar = {
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp)) {
                Text("MyCash Business", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Ink)
                Text("Rekod kewangan perniagaan • Offline", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("⌂") }, label = { Text("Ringkasan") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("≡") }, label = { Text("Transaksi") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Text("▤") }, label = { Text("Hutang") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Text("▥") }, label = { Text("Laporan") })
            }
        },
        floatingActionButton = {
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (tab != 2 && tab != 3) {
                    ExtendedFloatingActionButton(
                        onClick = { receiptLauncher.launch(null) },
                        containerColor = Color(0xFF245B78),
                        contentColor = Color.White,
                        text = { Text("Scan resit") },
                        icon = { Text("▣") }
                    )
                }
                if (tab != 3) FloatingActionButton(onClick = { if (tab == 2) showDebt = true else showEntry = true }, containerColor = Green, contentColor = Color.White) {
                    Text("+", style = MaterialTheme.typography.headlineMedium)
                }
            }
        }
    ) { padding ->
        when (tab) {
            0 -> SummaryScreen(Modifier.padding(padding), income, expense, balance, receivable, payable, entries.take(5))
            1 -> EntriesScreen(Modifier.padding(padding), entries) { path -> selectedReceipt = path }
            2 -> DebtsScreen(Modifier.padding(padding), debts,
                onToggle = { debt ->
                    debts = debts.map { if (it.id == debt.id) it.copy(settled = !it.settled) else it }
                    saveDebts(debts.reversed())
                })
            else -> ReportsScreen(Modifier.padding(padding), entries)
        }
    }

    if (selectedReceipt.isNotBlank()) ReceiptImageDialog(selectedReceipt) { selectedReceipt = "" }

    if (showEntry) EntryDialog(
        onDismiss = { showEntry = false },
        onSave = { kind, amount, category, note ->
            val now = System.currentTimeMillis()
            val date = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("ms", "MY")).format(Date(now))
            entries = (entries + Entry(now, kind, amount, category, note, date)).sortedByDescending { it.id }
            saveEntries(entries.reversed()); showEntry = false
        }
    )
    if (showDebt) DebtDialog(
        onDismiss = { showDebt = false },
        onSave = { kind, person, amount, note ->
            debts = (debts + Debt(System.currentTimeMillis(), kind, person, amount, note, false)).sortedByDescending { it.id }
            saveDebts(debts.reversed()); showDebt = false
        }
    )
    if (showReceiptReview) ReceiptReviewDialog(
        detectedAmount = receiptTotal,
        detectedText = receiptText,
        errorMessage = receiptError,
        onDismiss = { showReceiptReview = false },
        onSave = { amount ->
            val now = System.currentTimeMillis()
            val date = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("ms", "MY")).format(Date(now))
            entries = (entries + Entry(now, "Keluar", amount, "Stok / bahan", "Pembelian melalui scan resit", date, receiptPath)).sortedByDescending { it.id }
            saveEntries(entries.reversed())
            showReceiptReview = false
            receiptPath = ""
        }
    )
}

@Composable
fun SummaryScreen(modifier: Modifier, income: Double, expense: Double, balance: Double,
                  receivable: Double, payable: Double, recent: List<Entry>) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Ink), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("BAKI BERSIH", color = Color.LightGray, style = MaterialTheme.typography.labelMedium)
                    Text(rm(balance), color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column { Text("Duit masuk", color = Color(0xFFB6E9D1)); Text(rm(income), color = Color.White, fontWeight = FontWeight.SemiBold) }
                        Column { Text("Duit keluar", color = Color(0xFFFFC3C3)); Text(rm(expense), color = Color.White, fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
        }
        item { Text("Ringkasan hutang", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallMetric("Pelanggan berhutang", receivable, Green, Modifier.weight(1f))
                SmallMetric("Hutang pembekal", payable, Red, Modifier.weight(1f))
            }
        }
        item { Text("Transaksi terkini", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        if (recent.isEmpty()) item { EmptyText("Belum ada transaksi. Tekan + untuk mula merekod.") }
        items(recent) { EntryRow(it) }
        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
fun SmallMetric(title: String, amount: Double, color: Color, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            Text(rm(amount), color = color, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun EntriesScreen(modifier: Modifier, entries: List<Entry>, onReceiptClick: (String) -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Semua transaksi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        if (entries.isEmpty()) item { EmptyText("Tiada rekod lagi. Tekan + untuk tambah duit masuk atau keluar.") }
        items(entries) { EntryRow(it, onReceiptClick) }
        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
fun EntryRow(entry: Entry, onReceiptClick: (String) -> Unit = {}) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(entry.category, fontWeight = FontWeight.SemiBold)
                if (entry.note.isNotBlank()) Text(entry.note, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Text(entry.date, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                if (entry.receiptPath.isNotBlank() && File(entry.receiptPath).exists()) Text("Lihat gambar resit", Modifier.clickable { onReceiptClick(entry.receiptPath) }, color = Color(0xFF245B78), style = MaterialTheme.typography.labelSmall)
            }
            Text((if (entry.kind == "Masuk") "+" else "−") + rm(entry.amount),
                color = if (entry.kind == "Masuk") Green else Red, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun DebtsScreen(modifier: Modifier, debts: List<Debt>, onToggle: (Debt) -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Rekod hutang", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { Text("Tandakan selesai apabila hutang telah dibayar atau diterima.", style = MaterialTheme.typography.bodySmall, color = Color.Gray) }
        if (debts.isEmpty()) item { EmptyText("Belum ada rekod hutang. Tekan + untuk tambah.") }
        items(debts) { debt ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(debt.person, fontWeight = FontWeight.SemiBold)
                            Text(debt.kind, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        Text(rm(debt.amount), fontWeight = FontWeight.Bold, color = if (debt.kind == "Pelanggan berhutang") Green else Red)
                    }
                    if (debt.note.isNotBlank()) Text(debt.note, style = MaterialTheme.typography.bodySmall)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (debt.settled) "Selesai" else "Belum selesai", color = if (debt.settled) Green else Red, style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { onToggle(debt) }) { Text(if (debt.settled) "Buka semula" else "Tandakan selesai") }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
fun EntryDialog(onDismiss: () -> Unit, onSave: (String, Double, String, String) -> Unit) {
    var kind by remember { mutableStateOf("Masuk") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Jualan") }
    var note by remember { mutableStateOf("") }
    val categories = if (kind == "Masuk") listOf("Jualan", "Modal", "Pendapatan lain") else listOf("Stok / bahan", "Sewa", "Bil", "Gaji", "Pengangkutan", "Lain-lain")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah transaksi") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = kind == "Masuk", onClick = { kind = "Masuk"; category = "Jualan" }, label = { Text("Duit masuk") })
                    FilterChip(selected = kind == "Keluar", onClick = { kind = "Keluar"; category = "Stok / bahan" }, label = { Text("Duit keluar") })
                }
                OutlinedTextField(amount, { amount = it }, label = { Text("Jumlah (RM)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Text("Kategori", style = MaterialTheme.typography.labelMedium)
                Column {
                    categories.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            pair.forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) }) }
                        }
                    }
                }
                OutlinedTextField(note, { note = it }, label = { Text("Catatan (pilihan)") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = {
            val value = amount.replace(",", ".").toDoubleOrNull()
            if (value != null && value > 0) onSave(kind, value, category, note)
        }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@Composable
fun DebtDialog(onDismiss: () -> Unit, onSave: (String, String, Double, String) -> Unit) {
    var kind by remember { mutableStateOf("Pelanggan berhutang") }
    var person by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah rekod hutang") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(selected = kind == "Pelanggan berhutang", onClick = { kind = "Pelanggan berhutang" }, label = { Text("Pelanggan") })
                    FilterChip(selected = kind == "Hutang pembekal", onClick = { kind = "Hutang pembekal" }, label = { Text("Pembekal") })
                }
                OutlinedTextField(person, { person = it }, label = { Text("Nama orang / syarikat") }, singleLine = true)
                OutlinedTextField(amount, { amount = it }, label = { Text("Jumlah (RM)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text("Catatan (pilihan)") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = {
            val value = amount.replace(",", ".").toDoubleOrNull()
            if (person.isNotBlank() && value != null && value > 0) onSave(kind, person.trim(), value, note)
        }) { Text("Simpan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}


@Composable
fun ReportsScreen(modifier: Modifier, entries: List<Entry>) {
    var period by remember { mutableStateOf("Harian") }
    val now = Calendar.getInstance()
    val start = (now.clone() as Calendar).apply {
        when (period) {
            "Harian" -> { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            "Mingguan" -> { val dow = get(Calendar.DAY_OF_WEEK); val back = if (dow == Calendar.SUNDAY) 0 else (dow - Calendar.SUNDAY + 7) % 7; add(Calendar.DAY_OF_YEAR, -back); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            else -> { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        }
    }
    val end = (start.clone() as Calendar).apply {
        when (period) { "Harian" -> add(Calendar.DAY_OF_YEAR, 1); "Mingguan" -> add(Calendar.DAY_OF_YEAR, 5); else -> add(Calendar.MONTH, 1) }
    }
    val filtered = entries.filter { e ->
        val c = Calendar.getInstance().apply { timeInMillis = e.id }
        val within = e.id >= start.timeInMillis && e.id < end.timeInMillis
        val weekday = c.get(Calendar.DAY_OF_WEEK) in Calendar.SUNDAY..Calendar.THURSDAY
        within && (period != "Mingguan" || weekday)
    }
    val sales = filtered.filter { it.kind == "Masuk" }.sumOf { it.amount }
    val costs = filtered.filter { it.kind == "Keluar" }.sumOf { it.amount }
    val labelFmt = SimpleDateFormat("dd MMM yyyy", Locale("ms", "MY"))
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Laporan jualan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Harian", "Mingguan", "Bulanan").forEach { p -> FilterChip(selected = period == p, onClick = { period = p }, label = { Text(p) }) } } }
        item { Text(when(period) { "Harian" -> labelFmt.format(Date(now.timeInMillis)); "Mingguan" -> "${labelFmt.format(Date(start.timeInMillis))} – ${labelFmt.format(Date(end.timeInMillis - 1))} (Ahad–Khamis)"; else -> SimpleDateFormat("MMMM yyyy", Locale("ms", "MY")).format(Date(now.timeInMillis)) }, color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
        item { SmallMetric("Jumlah jualan / duit masuk", sales, Green, Modifier.fillMaxWidth()) }
        item { SmallMetric("Jumlah perbelanjaan", costs, Red, Modifier.fillMaxWidth()) }
        item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("Baki bersih", color = Color.Gray); Text(rm(sales-costs), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = if (sales-costs >= 0) Green else Red) } } }
        item { Text("Butiran transaksi (${filtered.size})", fontWeight = FontWeight.Bold) }
        if (filtered.isEmpty()) item { EmptyText("Tiada transaksi dalam tempoh ini.") }
        items(filtered.sortedByDescending { it.id }) { EntryRow(it) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun ReceiptImageDialog(path: String, onDismiss: () -> Unit) {
    val bitmap = remember(path) { BitmapFactory.decodeFile(path) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Gambar resit") },
        text = { if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = "Gambar resit", modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) else Text("Gambar resit tidak ditemui.") },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } })
}

@Composable
fun EmptyText(message: String) {
    Card(Modifier.fillMaxWidth()) { Text(message, Modifier.padding(18.dp), color = Color.Gray) }
}

fun rm(value: Double): String = "RM " + String.format(Locale.US, "%,.2f", value)


@Composable
fun ReceiptReviewDialog(
    detectedAmount: String,
    detectedText: String,
    errorMessage: String,
    onDismiss: () -> Unit,
    onSave: (Double) -> Unit
) {
    var amount by remember(detectedAmount) { mutableStateOf(detectedAmount) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Semak jumlah resit") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (errorMessage.isNotBlank()) Text(errorMessage, color = Red, style = MaterialTheme.typography.bodySmall)
                Text("Jumlah pembelian (RM)")
                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                Text("Kategori: Stok / bahan", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Text("Semak jumlah akhir pada resit sebelum simpan.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                if (detectedText.isNotBlank()) {
                    Text("Teks dibaca: " + detectedText.take(180).replace("\\n", " "), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val value = amount.replace(",", ".").toDoubleOrNull()
                if (value != null && value > 0) onSave(value)
            }) { Text("Simpan transaksi") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

fun detectReceiptTotal(rawText: String): String {
    val lines = rawText.lines().map { it.trim() }.filter { it.isNotBlank() }
    val amountRegex = Regex("""(?:RM\s*)?([0-9]{1,6}(?:[.,][0-9]{2}))""", RegexOption.IGNORE_CASE)
    val keywords = listOf("GRAND TOTAL", "TOTAL DUE", "AMOUNT DUE", "NET TOTAL", "TOTAL", "JUMLAH")
    for (keyword in keywords) {
        val candidates = lines.filter { it.uppercase(Locale.ROOT).contains(keyword) }
        for (line in candidates.asReversed()) {
            val matches = amountRegex.findAll(line).toList()
            if (matches.isNotEmpty()) return matches.last().groupValues[1].replace(",", ".")
        }
    }
    // Fallback: largest monetary amount found, for manual confirmation.
    val all = amountRegex.findAll(rawText).mapNotNull { it.groupValues[1].replace(",", ".").toDoubleOrNull() }.toList()
    return all.maxOrNull()?.let { String.format(Locale.US, "%.2f", it) } ?: ""
}
