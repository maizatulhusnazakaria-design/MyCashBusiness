# MyCash Business (Android)

Aplikasi Android ringkas untuk merekod kewangan perniagaan secara offline.

## Fungsi versi 1.0
- Rekod duit masuk dan keluar
- Kategori transaksi dan catatan
- Ringkasan baki bersih, jumlah masuk dan keluar
- Rekod pelanggan yang berhutang
- Rekod hutang kepada pembekal
- Tandakan hutang selesai / buka semula
- Scan resit menggunakan kamera dan OCR (Google ML Kit)
- Cadangan jumlah akhir secara automatik, boleh disemak/edit sebelum simpan
- Rekod pembelian sebagai transaksi keluar kategori Stok / bahan
- Data disimpan secara lokal dalam SharedPreferences telefon

## Cara bina APK
1. Pasang Android Studio pada komputer.
2. Extract ZIP ini.
3. Buka folder `MyCashBusiness` melalui Android Studio.
4. Tunggu Gradle sync selesai dan benarkan Android Studio memuat turun komponen yang diperlukan.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Nota
- Projek ini ialah kod sumber Android Studio, bukan APK yang telah dikompilasi.
- Data disimpan pada peranti dan tidak disegerakkan ke cloud.
- Nyahpasang aplikasi atau clear app data boleh memadam rekod. Buat backup telefon sebelum reset/peranti ditukar.
- Scan resit menggunakan kamera dan OCR; bacaan jumlah bergantung pada kualiti gambar dan susun atur resit. Pengguna perlu semak jumlah sebelum simpan.
- Aplikasi memerlukan internet sekali untuk Gradle memuat turun library ML Kit semasa proses build; pemprosesan OCR berlaku pada peranti selepas library tersedia.
- Versi ini belum menyimpan imej resit atau mempunyai eksport Excel/PDF.


## Bina APK melalui GitHub Actions (tanpa komputer)
1. Buat repository GitHub baharu melalui browser telefon.
2. Muat naik fail `MyCashBusiness_Android_Project_v1.1_ReceiptScanner.zip` ke root repository.
3. Dalam GitHub, pilih **Add file > Create new file**. Namakan fail `.github/workflows/build-apk.yml` dan tampal kandungan fail `build-apk.yml` yang disertakan bersama projek.
4. Buka tab **Actions**, pilih **Build MyCash Business APK**, kemudian tekan **Run workflow**.
5. Apabila proses berjaya, buka run yang selesai dan muat turun artifact `MyCashBusiness-debug-apk`.
6. Extract ZIP artifact dan pasang `app-debug.apk` pada telefon Android.

Workflow ini memerlukan akaun GitHub dan penggunaan GitHub Actions tertakluk pada kuota/terma GitHub. APK debug tidak ditandatangani untuk edaran Play Store; ia sesuai untuk pemasangan ujian sendiri.
